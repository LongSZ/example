#pragma once

#include <gdiobj.h>

#define COLOR_TITLEBAR			Color(60, 65, 70)
#define COLOR_TITLEBAR_HL		Color(90, 95, 100)

#define COLOR_LISTBOX_BG		Color(60, 60, 60)
#define COLOR_LISTBOX_SELECT	Color(0,135,204)
#define COLOR_LISTBOX_DESELECT	Color(40, 45, 50)

#define COLOR_LISTBOX_TEXT		Color(0,135,204)
#define COLOR_LISTBOX_SELTEXT	Color(220, 220, 220)