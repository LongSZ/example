//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WindowsProject5.rc
//
#define IDI_ICON1                       101
#define IDI_ICON2                       102
#define IDI_ICON3                       103
#define IDI_ICON4                       104
#define IDI_ICON5                       105
#define IDI_ICON6                       106
#define IDI_ICON7                       107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
