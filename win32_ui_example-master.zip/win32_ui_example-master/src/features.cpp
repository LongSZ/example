#include "features.h"

features::features()
{
    //ctor
    active = 0;
}


features::~features()
{
    //dtor
}

void features::activate(int a) {
    this->active = x;
}
