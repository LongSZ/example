#ifndef FEATURES_H
#define FEATURES_H


class features
{
    private:
         int active;

    public:
        features();
        virtual ~features();
        void activate(int a);

    protected:


};

#endif // FEATURES_H
