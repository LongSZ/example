# win32-custom-titlebar

C99 / C++98 code to render a custom title bar on Windows.

[Read this article](https://kubyshkin.name/posts/win32-window-custom-title-bar-caption/) for
more details.

## Building

To build the project run `build.bat` in an MSVC command prompt.

You can also build with Clang by running:

```bash
clang-cl -D UNICODE main.c
```
