<img src="Notepad.ico" width=32/> Notepad
=======

Reimplementation of Windows Notepad including the edit control

![Windows](https://img.shields.io/badge/platform-Windows-blue.svg)
[![Releases](https://img.shields.io/github/release/RadAd/Notepad.svg)](https://github.com/RadAd/Notepad/releases/latest)
[![commits-since](https://img.shields.io/github/commits-since/RadAd/Notepad/latest.svg)](commits/master)
[![Build](https://img.shields.io/appveyor/ci/RadAd/Notepad.svg)](https://ci.appveyor.com/project/RadAd/Notepad)
